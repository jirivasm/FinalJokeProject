package com.example.androidjokelib;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.javajokelibrary.JokeJavaLib;

public class JokeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke);

        Intent i = getIntent();
        String joke =   i.getStringExtra("result");

        JokeJavaLib jokes  = new JokeJavaLib(joke);
        TextView text = findViewById(R.id.java_lib_joke);

        text.setText(jokes.GetJokes());
    }
}