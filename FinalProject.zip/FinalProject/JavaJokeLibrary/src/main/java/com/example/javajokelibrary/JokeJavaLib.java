package com.example.javajokelibrary;

import com.udacity.gradle.builditbigger.backend.MyBean;

public class JokeJavaLib {


    MyBean bean = new MyBean();

    public JokeJavaLib(String data) {
        bean.setData(data);
    }


    public String GetJokes() {
        return bean.getData();
    }
}
